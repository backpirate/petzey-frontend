import './allappointment.css';
import Profilepic from '../../../images/petowner.jpeg';
import axios from 'axios'
import React, { Component } from 'react'
import '/node_modules/bootstrap/dist/css/bootstrap.min.css';



class Allpatients extends Component {
    constructor(props) {
        super(props)
        this.state = {patients: []}
        }
      
        componentDidMount(){
            axios.get("http://localhost:8092/pet/getpet")
            .then(response=> {console.log(response)
           this.setState({patients: response.data})})
          .catch(error=>{console.log(error)})
        }
      
        render() {
                const { patients}= this.state
                    return (
                        <div className=''>
                             <div className='sample col-10'>
                                <div className='search'>
                                    <nav class="navbar navbar-expand-md ">
                                        <h3>All Appointments</h3>
                                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
                                            <span class="navbar-toggler-icon"></span>
                                        </button>
                                        <div class="collapse navbar-collapse">
                                            <ul class="navbar-nav ml-auto">
                                            <div className='date'>
                                                <button className="btn btn-light">
                                                    <a href='calendar'><i className="fas fa-calendar input-prefix "></i></a>
                                                    <p>Select date</p>
                                                </button>
                                            </div> 
                                            <div className='status'>
                                                <select className= "myList" onChange = "favTutorial()">
                                                    <option value="All" selected>Status</option>
                                                    <option> Open </option>  
                                                    <option> Closed </option>  
                                                    <option> Cancelled </option>
                                                </select> 
                                            </div> 
                                            <div className='newappointment'>
                                                <button type="button" className="btn btn-danger"><a href='New_Appointment' className='text-white'>+ New Appointment</a></button>
                                            </div> 
                                            </ul>
                                        </div>
                                        </nav>

                                </div>
                                <hr className='col-10'/>                            
                            </div>
                        <div>
                                {
                                    patients.length ?
                                    patients.map(patients => 
                                    <div key={patients.id}>
                                    <div className='recpappointment'>
                                    <div className="card-group">
                                        <div className="card">
                                            <div className="card-body">
                                                <div className='card-title d-flex'>
                                                    <div>        
                                                        <img src={Profilepic} alt='dp' className='rounded'/>
                                                    </div>
                                                <div>
                                                    <h6 className="card-text">{patients.petName}</h6>
                                                    <p className='text-muted1'> {patients.gender}</p>
                                                    <p className='text-muted'>Owner:John Doe</p>
                                                </div>
                                            </div>
                                            <div className='d-flex'>
                                                <div>
                                                    <h4 className='text-muted'><time>10:30</time></h4>
                                                    <h4 className='text-muted'>12/6/2020</h4>
                                               </div>
                                                <div>
                                                    <i className="bi bi-camera-video-fill"></i>
                                                    <i className="bi bi-telephone-fill"></i>
                                                </div>
                                            </div>
                                            <hr/>
                                            <div className='d-flex justify-content-around'>
                                                <a href='Details'><h6>Details</h6></a>
                                                <a href='Details'><h6>Feedback</h6></a>
                                            </div>
                                        </div>
                                    </div>
                                    </div> 
                                    </div>
                                    </div>):
                                    null
                                }
                        </div>
                       </div> 

                    )
                }
    }
export default Allpatients