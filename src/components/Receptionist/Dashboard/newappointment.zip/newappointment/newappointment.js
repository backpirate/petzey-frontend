import React from 'react';
import './newappointment.css';

const newappointment = () => {
 return (
    <div>
        <div className='form'>
        <p class='col'><i class="bi bi-arrow-left"></i>Back to appointments</p>
          <h4>New Appointment</h4>
          <hr/>
          {/* <p className="new-appointment-calendar-text d-flex justify-content-center">Your Schedule</p>*/}
          <button type="button" class="btn btn-light"> <i class="bi bi-calendar"></i>Today</button> 
          <div>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
            <button type="button" class='btn btn-outline-dark btn-lg'>11:00</button>
            <button type="button" class='btn btn-outline-dark btn-lg'>11:00</button>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
          </div>
          <div>
            <button type="button" class='btn btn-outline-dark btn-lg'>11:00</button>
            <button type="button" class='btn btn-light btn-lg'>11:00</button>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
            <button type='button' class='btn btn-primary btn-lg' disabled>11:00</button>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
          </div>
          <div>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
            <button type="button" class='btn btn-outline-dark btn-lg'>11:00</button>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
            <button type='button' class='btn btn-secondary btn-lg' disabled>11:00</button>
          </div>
          <div>
            <h6>Patient Details</h6>
          </div>
          <div>
            <p class='text-muted'>Pet Parent</p>
          </div>
          <div className='line'>  
            <i  class="bi bi-search"></i>
            <input></input>
          </div>
          <div>
            <p class='text-muted'>Pet Name</p>
          </div>
          <div className='line'>  
            <i  class="bi bi-search"></i>
            <input></input>
          </div>
          <div>
            <h6>Other Details</h6>
          </div>
          <div>
            <p class='text-muted'>Pet Issues</p>
          </div>
          <div className='line'>
            <i  class="bi bi-search"></i>
            <input></input>
          </div>
          <div className='reason'>
            <p class='text-muted'>Reason for Visit</p>
            {/* <textarea name="message" rows="5" cols="30"></textarea> */}
            <input type='text'></input>
          </div>
          <div className='ConfirmCancel'>
            <button type="button" class="btn btn-primary" >Cancel</button>
            <button type="button" class="btn btn-danger">Book Appointment</button>
          </div>
        </div>
    </div>
  )
}

export default newappointment