import React from 'react'
import './apporeport.css'
import { Link } from 'react-router-dom'
import Profilepic from '../../../images/petowner.jpeg'
import Container from 'react-bootstrap/Container';
import { Card } from 'react-bootstrap';

const apporeport = () => {
  return (
    <div>
        <div>
            <div className='body'>
                <div className='column'>
                    <Link to={"/allappointments"} className='nav-link'>
                        <p class='col'><i class="bi bi-arrow-left"></i>Back to appointments</p>
                    </Link>
                    <h4>#ID-239143</h4>
                    <div className='date'>
                        <a href='calendar'><i className="fas fa-calendar input-prefix "></i></a>
                        <p>25th March,2022</p>
                        <i class="bi bi-clock"></i>
                        <Container className='push'>
                            <i class="bi bi-chat-left-text-fill"></i>
                            <i class="bi bi-telephone-fill"></i>
                            <i class="bi bi-camera-video-fill"></i>
                        </Container>
                    </div>
                    <p>Pet issues: <span>Hand injury</span></p>
                    <p>Response for visit : <span className='text-muted'>Dog hasn't feeling wer sonce Tuesday</span></p>
                    <p className='text-muted'>Confirmed by <span>Jane Doe</span></p>
                    <hr className='col-11'/>    
                </div>
                <div className='displayappointment'>
                
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="card-body d-flex">
                                <div className='mr-5'>
                                    <div className='card-title d-flex'>
                                        <div>
                                            <img src={Profilepic} alt='dp' class='rounded'/>
                                        </div>
                                        <div>
                                            <p className='text-muted'>Patient</p>
                                            <h6 class="card-text">Dogo</h6>
                                            <p class='text-muted1'> Dog,Afghan hound</p>
                                        </div>
                                    </div>
                                    <div className='d-flex'>
                                        <p className='text-muted'>Gender :</p><h6>Male</h6>
                                    </div>
                                    <div className='d-flex'>
                                        <p className='text-muted'>Age:</p><h6>2.2years</h6>
                                    </div>
                                </div>
                                <div>
                                    <div className='card-title d-flex'>
                                        <div>
                                            <img src={Profilepic} alt='dp' class='rounded'/>
                                        </div>
                                        <div>
                                            <p className='text-muted'>Pet Owner</p>
                                            <h6 class="card-text">Jack Hall</h6>
                                        </div>
                                    </div>
                                    <p className='text-muted'><i class="bi bi-envelope p-2"></i>johndoe@gmail.com</p>
                                    <p className='text-muted'><i class="bi bi-telephone-fill p-2"></i>+44 2071838750</p>
                                    <p className='text-muted'><i class="bi bi-house p-2"></i>Bangalore,Karnataka</p>
                        
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-body"> 
                                    <div className='card-title d-flex'>  
                                        <div >        
                                            <img src={Profilepic} alt='dp' class='rounded'/>
                                        </div>
                                        <div>
                                            <p className='text-muted'>Doctor</p>
                                            <h6 class="card-text">Dr.Jhon Doe</h6>
                                            <p className='text-muted'>NAVLE</p>
                                        </div>
                                    </div>
                                    <div className='d-flex'>
                                        <div className='Profile_Text'>
                                            <p class='text-muted'>NPI NO</p>
                                            <p class='text-muted'>Clinic</p>
                                        </div>
                                        <div className='Profile_Text'>
                                            <p class='text-secondary'><span>:</span></p>
                                            <p class='text-secondary'><span>:</span></p>
                                        </div>
                                        <div>
                                            <p ><span>659862111</span></p>
                                            <p><span>St.jhon's Clinic,</span></p>
                                            <p><span>Utah,Us</span></p>
                                        </div>
                                        <div>
                                            <p className='text-muted'><i class="bi bi-envelope p-2"></i>johndoe@gmail.com</p>
                                            <p className='text-muted'><i class="bi bi-telephone-fill p-2"></i>+44 2071838750</p>
                                            <p className='text-muted'><i class="bi bi-house p-2"></i>Bangalore,Karnataka</p>
                                        </div>
                                    </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className='apporeport'>
            <div className='d-flex'>
                <h4 className='text-muted'>Appointment Report</h4>
                <div className='card'>
                    <i class="bi bi-download"></i>
                    <p>Report</p>
                </div>
            </div>
            <hr className='col-11'/>
        </div>
        <div className='allreports'>
            <div className='card'>
               <div class="card-body">
                    <h5 class="card-title">Prescriptions</h5>
                    <div className='card'>
                        <div className='card-title-body'>
                            <h6>1. Crocine</h6>
                            <p text-muted>Days:10</p>
                            <div className='d-flex'>
                                <p>Don't use hot water to consume tablets</p>
                                <i class="bi bi-three-dots"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}


export default apporeport